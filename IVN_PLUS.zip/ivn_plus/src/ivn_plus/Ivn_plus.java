/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ivn_plus;
//importamos la libreria jaava.sql
import java.sql.*;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Yeison Stiven Zape Barona
 */
public class Ivn_plus {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // configuramos el acceso a la base de datos
        String usuario="root";
        String password="yeison247";
        String url="jdbc:mysql://localhost:3306/ivn_plus_usuarios";
        Connection conexion;
        Statement st;
        ResultSet rs;
        
        try {
            //configuramos el controlador jdbc
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Ivn_plus.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            //se realiza la conexion a la base de datos
            conexion=DriverManager.getConnection(url,usuario,password);
            st=conexion.createStatement();
            //sentencia para consultar datos
            /*rs=st.executeQuery("SELECT * FROM usuarios");
            rs.next();
            do{ 
            System.out.println(rs.getString("nom")+" : "+ " "+rs.getString("apell")+" : "+rs.getString("email"));
            }while(rs.next());*/
            
            //sentencia para insertar datos
            /*st.executeUpdate("insert into usuarios values('yeison','jimenez','2002-04-11','yyyei776','yyyei776','gato@gmail.com','cedula','442277665')");
            rs=st.executeQuery("SELECT * FROM usuarios");
            rs.next();
            do{ 
            System.out.println(rs.getString("nom")+" : "+ " "+rs.getString("apell")+" : "+rs.getString("email"));
            }while(rs.next());*/
            //sentencia para actualizar un dato
            
            /*st.executeUpdate("update usuarios set nom='Diana Marcela' where email='camilo@hotmail.com'");
            rs=st.executeQuery("SELECT * FROM usuarios");
            rs.next();
            do{ 
            System.out.println(rs.getString("nom")+" : "+ " "+rs.getString("apell")+" : "+rs.getString("email"));
            }while(rs.next());*/
            //sentencia patra eliminar un registro
            st.executeUpdate("delete from usuarios where apell='jimenez'");
            rs=st.executeQuery("SELECT * FROM usuarios");
            rs.next();
            do{ 
            System.out.println(rs.getString("nom")+" : "+ " "+rs.getString("apell")+" : "+rs.getString("email"));
            }while(rs.next());
        } catch (SQLException ex) {
            Logger.getLogger(Ivn_plus.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
    
}
